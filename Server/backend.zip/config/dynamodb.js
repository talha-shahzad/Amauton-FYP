// backend/config/dynamodb.js
const AWS = require("aws-sdk");

// configure your region
AWS.config.update({ region: process.env.AWS_REGION || "us-east-1" });

const ddb = new AWS.DynamoDB.DocumentClient();

module.exports = ddb;
