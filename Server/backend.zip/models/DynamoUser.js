const AWS = require("aws-sdk");
const { v4: uuidv4 } = require("uuid");

AWS.config.update({ region: "us-east-1" });
const ddb = new AWS.DynamoDB.DocumentClient();
const TABLE = "Users";
const EMAIL_INDEX = "email-index";

async function getUserByEmail(email) {
  const { Items } = await ddb.query({
    TableName: TABLE,
    IndexName: EMAIL_INDEX,
    KeyConditionExpression: "email = :e",
    ExpressionAttributeValues: { ":e": email },
  }).promise();
  return Items[0];
}

async function getUserById(userId) {
  const { Item } = await ddb.get({
    TableName: TABLE,
    Key: { userId }
  }).promise();
  return Item;
}

async function createUser({ name, email, passwordHash, contactNumber }) {
  const user = {
    userId: uuidv4(),
    name,
    email,
    passwordHash,
    contactNumber,
    createdAt: Date.now()
  };
  await ddb.put({ TableName: TABLE, Item: user }).promise();
  return user;
}

async function updateUser(userId, updates) {
  const updateExpr = [];
  const exprAttrNames = {};
  const exprAttrValues = {};

  for (const key in updates) {
    updateExpr.push(`#${key} = :${key}`);
    exprAttrNames[`#${key}`] = key;
    exprAttrValues[`:${key}`] = updates[key];
  }

  const UpdateExpression = `SET ${updateExpr.join(", ")}`;

  await ddb.update({
    TableName: TABLE,
    Key: { userId },
    UpdateExpression,
    ExpressionAttributeNames: exprAttrNames,
    ExpressionAttributeValues: exprAttrValues
  }).promise();

  return getUserById(userId);
}

module.exports = {
  getUserByEmail,
  getUserById,
  createUser,
  updateUser
};
